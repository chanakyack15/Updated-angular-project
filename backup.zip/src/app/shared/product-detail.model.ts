export class ProductDetail {
  ID:number;
  Name:string;
  Price:string;
  quantity:string;
}


