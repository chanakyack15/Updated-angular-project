export class CartDetail {
  id:number;
  name:string;
  price:string;
  quantity:string;
}
